package com.nononsenseapps.filepicker.sample.fastscroller;

/**
 * Just for theme sample purposes
 */
public class FastScrollerFilePickerActivity2 extends FastScrollerFilePickerActivity {
}
