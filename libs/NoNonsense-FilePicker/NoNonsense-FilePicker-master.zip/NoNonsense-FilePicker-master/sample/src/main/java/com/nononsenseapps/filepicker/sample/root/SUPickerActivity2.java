package com.nononsenseapps.filepicker.sample.root;

/**
 * Just for second theme
 */
public class SUPickerActivity2 extends SUPickerActivity {
}
